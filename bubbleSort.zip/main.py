import random
#create a list from 0 to 99
l = list(range(0,100))
#shuffle the list
random.shuffle(l)


for e in l:
   print(e)
print("shuffle".center(60,"*"))
#sorts the list
#se until when in the list we have to search
fim = len(l)
#se if we still have values to shuffle
while fim > 1:
  trocou = False
  #says who are the values
  x = 0
  #se if we still have values to verify
  while x < (fim -1):
    #se whose the biggest value
    if(l[x]) > (l[x+1]):
      trocou = True
      #exchange the 1 value with the 2
      l[x],l[x+1] = l[x+1],l[x]
    x+=1
  #stops the function if no itens were changed
  if not trocou:
    break
  fim -= 1
  
for e in l:
   print(e)
