l = list(range(3,400,5))
def search(lista,conteudo):
  #gets a list and a desired information and finds that desired information in the list and returns the position 
  conteudo = str(conteudo)
  l = lista
  for index, content in enumerate(l):
    if str(content) == str(content):
      return index
      break