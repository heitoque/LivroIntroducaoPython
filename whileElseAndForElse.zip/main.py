i = input("digite um numero")
#repetição
while i != "0":
    i = int(i)
    i-=1
#caso não entre na repetição isso vai acontecer:
else:
    print(" você digitou 0")
#independentemente de entrar ou não isso vai acontecer:
print("voce alcançou 0")