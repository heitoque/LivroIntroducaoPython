s = "bom dia eu acredito que eu amo uma menina chamada de veridis"
#procura da esquerda para a direita e retorna o primeiro que achar(-1 caso não encontre)
lf = s.find("a")
#procura da direita para a esquerda e retorna o primeiro que achar
rf = s.rfind("a")
print(f"amo esta da esquerda para a direita em {lf}, e da direita para a esquerda em {rf}") 
#tambem possui argumento de onde começar a procurar e onde terminar

#encontrar todas as ocorrencias
posicao = 0
posicoes = []
pesquisa = "b"
#enquanto for encontrado um valor
while posicao > -1 :
  posicao = s.find(pesquisa,posicao)
  if posicao >= 0:
    posicoes.append(posicao)
    #faz que não se procure na mesma posição
    posicao+=1

for x,y in enumerate(posicoes):
  print(f"a {x} ocorrencia de '{pesquisa}' acontece em: {y}")




