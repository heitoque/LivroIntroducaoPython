l = []
#add to the list and list containing a number and the double of the number
for a in range(100):
  l.append([a,a*2])
#for each list in l unpack the content of the list inside the list to x and y

#the l gives it first value and x and y recieve the values inside the value given by l

# a,b = x,y != for a,b in x,y 
# in the second its interpreted that the list that the for will run is (x,y) so it gives the value x to the variables and when they try to unpack it they will unpack the values inside of x so if x is a generator they will unpack all the values that the generator will create
for x,y in l:
  #print x and y and a blanck line
  print(x)
  print(y)
  print("") 