l = ["heitoque"," ","ama"," ","veridis"]
#the join method gets the content in every index in a list and transform them on a string by concatenating them
s = "".join(l)
print(s)