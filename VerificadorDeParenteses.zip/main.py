texto = input("digite o conjunto de parenteses")
parenteses = list(texto)
y = 0
for x in parenteses:
  if x == "(":
    y+=1
  elif x == ")":
    y-=1
  else:
    print("caracter errado")
    y = 1
    break
if y != 0 :
  print("erro")
else:
  print("sucesso")