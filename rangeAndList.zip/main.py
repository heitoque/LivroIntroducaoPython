#range() generates a stream of numbers and gives the numbers generated to a variable when requested(normally used to make control variable loops)
heitoque = range(1,10,2)
#list() takes a generator and transform it into a list
l = list(heitoque)
#enumerate is a generator. It takes the index and a variable in a list and creates a tuple 
print(list(enumerate(l)))
#can be used to acess both the index and the variable at once
for x,c in enumerate(l):
  print(f"index: {x} \ncontent: {c}\n")