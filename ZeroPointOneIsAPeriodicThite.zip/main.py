print(3*0.1)
#thats because 0.1 is a periodic tithe
#isso é porque 0.1 é uma dizima periodica       