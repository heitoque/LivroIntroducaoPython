tabela = {"alface":200,"batata":100,"tomate":125,"feijão":60}
#.keys()
print("\n"+".keys()".center(60,"*")+"\n")
#returns a generator with the keys of the dicionary[]
print("we have the following foods:")
for x,k in enumerate(tabela.keys()):
  print(f"{x+1}:{k}")
#.values()
print("\n"+".values()".center(60,"*")+"\n")
#return a generator with the values of the dicionary
print("the amounts of each item that we have are:")
for x,c in enumerate(tabela.values()):
  print(f"{x+1}:{c}")
#.items()
print("\n"+".items()".center(60,"*")+"\n")
#return a generator with a tuple containing the key and the value of every item
for k,c in tabela.items():
  print(f"foods:{k:.<10}amounts:{c:<10}")