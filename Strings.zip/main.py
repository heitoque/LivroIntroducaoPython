#using % to format a integer with 3 algarisms and 0 to the left
x = 3*0.1
y = 3
print("%03.2f %03d"%(x,y))
print("*"*60)
#spaces between integers with %
age = 22
print("%d"%age+"years old")
print("%03d"%age+"years old")
print("%3d"%age+"years old")
print("%-3d"%age+"years old")
print("*"*60)
#exemple of the book page 65
nome = "joão"
idade = 22
grana = 51.3
#name, age, money
#how to do with %
print("%s tem %d anos e R$%f no bolso"%(nome,idade,grana))
print("%12s tem %-3d anos e R$%.f no bolso"%(nome,idade,grana))
print("%-12s tem %03d anos e R$%.2f no bolso"%(nome,idade,grana))
print("%s tem %d anos e R$%.2f no bolso"%(nome,idade,grana))
#"%s is %d years old and has $%0.2f in his pocket" - in inglish

#how to do with . format
print("*"*60)
print("{} tem {} anos e R${} no bolso".format(nome,idade,grana))
print("{:>12} tem {:<3} anos e R${:.0f} no bolso".format(nome,idade,grana))
print("{:12} tem {:03} anos e R${:.2f} no bolso".format(nome,idade,grana))
print("{} tem {} anos e R${:.2f} no bolso".format(nome,idade,grana))

#how to do with f string
print("*"*60)
print(f"{nome} tem {idade} anos e R${grana} no bolso")
print(f"{nome:>12} tem {idade:<3} anos e R${grana:.0f} no bolso")
print(f"{nome:12} tem {idade:03} anos e R${grana:.2f} no bolso")
print(f"{nome} tem {idade} anos e R${grana:.2f} no bolso")

#how to put in the middle
print("*"*60)
print(f"{nome:^12} tem {idade:<3}anos e R${grana:.2f} no bolso")

#spliting strings

#how to get only one part of a string
print(f"{'_spliting_strings_':^60}".replace(" ","*").replace("_"," "))
data = "28/01/2006"
print(f"dia: {data[0:2]}")
print(f"mes: {data[3:5]}")
print(f"ano: {data[6:]}")

#how to not get the last part of a string
naoQuero = "eu não quero esses caracteres:69"
print("*"*60)
print(naoQuero[0:-2])